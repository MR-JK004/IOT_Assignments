import React,{ Component } from 'react';
import { Text,View,StyleSheet } from 'react-native';
import Svg, {Circle,Line, Text as SvgText } from 'react-native-svg';

class Speedometer extends Component {
  render() {
    const {value, maxSpeed ,colour,setcolour,speedReading,text,setText} = this.props;
    const radius = 100; 

    const angle = (value / maxSpeed) * 180; 

    const needleLength = 80;
    const x = radius + needleLength * Math.cos((angle - 180) * (Math.PI / 180));
    const y = radius + needleLength * Math.sin((angle - 180) * (Math.PI / 180));

      if(speedReading > 100){
        setcolour('lightsalmon');
        setText('Warning : Exceeding Speed Limits, RIP !!!');
      }
      else{
        setcolour('white');
        setText('');
      }


    return (
      <View style={styles.container}>
        <Svg height={2 * radius} width={2 * radius}>
          {/* Background Circle */}
          <Circle
            cx={radius}
            cy={radius}
            r={radius}
            fill="lightgray"
          />

          {/* Speedometer Circle */}
          <Circle
            cx={radius}
            cy={radius}
            r={radius - 10}
            fill={colour}
          />

          {/* Needle */}
          <Line
            x1={radius}
            y1={radius}
            x2={x}
            y2={y}
            stroke="red"
            strokeWidth="3"
          />

          {/* Speed Value Text */}
          <SvgText
            x={radius-20}
            y={radius + 30}
            fill="black"
            fontSize="20"
            textAnchor="middle"
          >
            {value}       mph
          </SvgText>
        </Svg>
        <Text style={styles.text}>
            {text}
          </Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  text:{
    marginTop:20,
  }
});

export default Speedometer;
