import React, { useState, useEffect } from 'react';
import { View, Text,StyleSheet} from 'react-native';
import Speedometer from './Speedometer';
const App = () => {
  const [speedReading, setSpeedReading] = useState(0);
  const [colour, setcolour] = useState();
  const [text,setText] = useState();

  useEffect(() => {
    const fetchSpeedReading = async () => {
      try {
        const response = await fetch('http://192.168.43.239/getSpeed');
        const data = await response.text();
        setSpeedReading(parseInt(data));
      } catch (error) {
        console.error('Error fetching speed reading:', error);
      }
    };

    fetchSpeedReading();
    const interval = setInterval(fetchSpeedReading, 5000);

    return () => {
      clearInterval(interval);
    };
  }, []);


  return (
    <View style={styles.container}>
      <Text style={styles.text}>SpeedoMeter Reading from MicroController</Text>
      <Speedometer 
        value={speedReading}
        maxSpeed={200}
        colour={colour}
        setcolour={setcolour}
        speedReading={speedReading}
        text={text}
        setText={setText}
      />
      {/* Render your Speedometer component here and pass the speedReading as a prop */}
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  text:{
    marginBottom:20,
    fontSize:17,
  }
});

export default App;